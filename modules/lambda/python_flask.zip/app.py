from flask import Flask, render_template
import boto3

app = Flask(__name__)
app.config['DEBUG'] = True

# Connect to DynamoDB
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table_name = 'city_table'
table = dynamodb.Table(table_name)

@app.route('/')
def display_items():
    try:
        # Retrieve all items from the DynamoDB table
        response = table.scan()
        items = response['Items']
        
        # Print items for debugging
        print("Items:", items)

        # Render the template with the items data
        return render_template('items.html', items=items)
    except Exception as e:
        error_message = "An error occurred: " + str(e)
        print("Error:", error_message)
        return render_template('error.html', error=error_message)

if __name__ == '__main__':
    app.run()
